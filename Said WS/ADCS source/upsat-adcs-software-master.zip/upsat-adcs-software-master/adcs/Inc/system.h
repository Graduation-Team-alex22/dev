#ifndef __SYSTEM_H
#define __SYSTEM_H

#define SYSTEM_APP_ID ADCS_APP_ID

#endif
