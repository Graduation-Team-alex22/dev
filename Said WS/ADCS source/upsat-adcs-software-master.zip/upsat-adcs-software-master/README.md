# UPSat ADCS Software
Attitude Determination and Control system Software for UPSat

## License

&copy; 2016 [Libre Space Foundation](http://librespacefoundation.org) & Commiters.

Licensed under the [GPLv3](LICENSE).
