#ifndef __WDG_H
#define __WDG_H

#include <stdint.h>

void wdg_reset_HK();

void wdg_reset_UART();

void wdg_IDLE();

#endif